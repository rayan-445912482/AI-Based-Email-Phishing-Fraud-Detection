from sklearn.linear_model import LogisticRegression

from src.features import CombinedFeatures, build_text_pipeline


def test_combined_features_shape():
    texts = [
        "hello world meeting tomorrow",
        "urgent verify account immediately",
        "team review project report",
        "click here to claim your prize",
    ]
    features = CombinedFeatures()
    matrix = features.fit_transform(texts)
    assert matrix.shape[0] == 4
    assert matrix.shape[1] > 0


def test_pipeline_fits_and_predicts():
    texts = [
        "hello world meeting tomorrow",
        "urgent verify account immediately",
        "team review project report",
        "click here to claim your prize",
    ] * 5
    labels = ["legitimate", "phishing", "legitimate", "phishing"] * 5

    pipeline = build_text_pipeline(LogisticRegression(max_iter=500))
    pipeline.fit(texts, labels)

    preds = pipeline.predict(texts)
    assert len(preds) == 20
    assert set(preds).issubset({"legitimate", "phishing"})


def test_lowercasing_applied():
    docs = [
        "Verify NOW verify now",
        "VERIFY now Verify NOW",
        "verify your account now",
        "Verify password immediately now",
        "VERIFY email account now",
        "verify now please verify",
        "VERIFY NOW urgent action",
        "verify account verify now",
        "Verify now confirm identity",
        "VERIFY now click link",
        "verify now security alert",
        "VERIFY now update details",
        "verify now prevent closure",
        "VERIFY now action required",
        "verify now confirm access",
        "VERIFY now secure account",
        "verify now reset password",
        "VERIFY now validate email",
        "verify now protect data",
        "VERIFY now trust center",
    ]
    features = CombinedFeatures()
    features.fit(docs)
    vocab = features.tfidf.vocabulary_
    assert "verify" in vocab
    assert "Verify" not in vocab
    assert "VERIFY" not in vocab
