from src.evaluation import calculate_metrics, compare_models


def test_metrics_calculation():
    y_true = ["legitimate", "phishing", "phishing", "legitimate"]
    y_pred = ["legitimate", "phishing", "legitimate", "legitimate"]
    metrics = calculate_metrics(y_true, y_pred)

    assert metrics["accuracy"] == 0.75
    assert metrics["precision"] == 1.0
    assert metrics["recall"] == 0.5
    assert abs(metrics["f1_score"] - 2 / 3) < 1e-9


def test_compare_models_sorted():
    metrics = [
        {"model": "a", "f1_score": 0.80},
        {"model": "b", "f1_score": 0.95},
        {"model": "c", "f1_score": 0.70},
    ]
    frame = compare_models(metrics)
    assert frame.iloc[0]["model"] == "b"
    assert frame.iloc[-1]["model"] == "c"


def test_metrics_with_scores():
    y_true = ["legitimate", "phishing", "phishing", "legitimate"]
    y_pred = ["legitimate", "phishing", "legitimate", "legitimate"]
    y_score = [0.1, 0.9, 0.4, 0.2]
    metrics = calculate_metrics(y_true, y_pred, y_score)

    assert metrics["roc_auc"] is not None
    assert 0 <= metrics["roc_auc"] <= 1
