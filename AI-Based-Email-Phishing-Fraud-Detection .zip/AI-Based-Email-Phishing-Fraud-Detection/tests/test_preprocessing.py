from src.preprocessing import (
    clean_and_prepare,
    clean_text,
    extract_signal_features,
    is_valid_text,
    normalize_label,
)


def test_normalize_phishing():
    assert normalize_label("phishing") == "phishing"
    assert normalize_label("Phishing Email") == "phishing"
    assert normalize_label("fraud") == "phishing"
    assert normalize_label("1") == "phishing"
    assert normalize_label(1) == "phishing"


def test_normalize_legitimate():
    assert normalize_label("legitimate") == "legitimate"
    assert normalize_label("Safe Email") == "legitimate"
    assert normalize_label("ham") == "legitimate"
    assert normalize_label("0") == "legitimate"


def test_spam_is_not_phishing():
    assert normalize_label("spam") is None


def test_normalize_invalid():
    assert normalize_label("maybe") is None
    assert normalize_label(None) is None


def test_clean_text():
    assert clean_text("<p>Hello</p>\n World") == "Hello World"
    assert clean_text(" multiple spaces ") == "multiple spaces"
    assert clean_text(None) == ""
    assert clean_text("&amp;") == "&"


def test_clean_and_prepare_runs():
    result = clean_and_prepare("URGENT verify your account now!")
    assert isinstance(result, str)
    assert len(result) > 0


def test_signal_features():
    features = extract_signal_features("Hello world! Visit https://example.com")
    assert features["url_count"] == 1
    assert features["exclamation_count"] == 1
    assert features["word_count"] >= 4


def test_valid_text():
    assert is_valid_text("This is a valid email text") is True
    assert is_valid_text("hi") is False
    assert is_valid_text("") is False
    assert is_valid_text("x" * 200_000) is False
