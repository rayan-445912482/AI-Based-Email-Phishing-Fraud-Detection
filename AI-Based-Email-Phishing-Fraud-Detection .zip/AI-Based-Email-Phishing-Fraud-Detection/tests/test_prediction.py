import pytest

from src.prediction import (
    MODEL_FILES,
    ModelNotTrainedError,
    models_status,
    predict_email,
)


def test_model_registry():
    assert set(MODEL_FILES.keys()) == {"random_forest", "svm", "naive_bayes"}


def test_unknown_model():
    with pytest.raises(ValueError):
        predict_email("hello world", "unknown_model")


def test_models_status_structure():
    status = models_status()
    assert "svm" in status
    assert "trained" in status["svm"]


def test_predict_without_model_raises():
    if MODEL_FILES["svm"].exists():
        pytest.skip("Model already trained.")
    with pytest.raises(ModelNotTrainedError):
        predict_email("hello world", "svm")
