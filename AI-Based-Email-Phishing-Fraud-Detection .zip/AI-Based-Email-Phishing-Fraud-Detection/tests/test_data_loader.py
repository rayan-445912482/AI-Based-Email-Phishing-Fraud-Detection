import pandas as pd
import pytest

from src.data_loader import DatasetError, load_dataset


def _make_dataset(tmp_path, n=300):
    legit = [f"Legitimate meeting reminder number {i} for the project" for i in range(n)]
    phish = [f"Urgent verify your account immediately click here number {i}" for i in range(n)]
    frame = pd.DataFrame({
        "text": legit + phish,
        "label": ["legitimate"] * n + ["phishing"] * n,
    })
    path = tmp_path / "emails.csv"
    frame.to_csv(path, index=False)
    return path


def test_load_valid(tmp_path):
    data = load_dataset(_make_dataset(tmp_path))
    assert len(data) == 600
    assert set(data["label"]) == {"legitimate", "phishing"}


def test_alternative_column_names(tmp_path):
    n = 300
    frame = pd.DataFrame({
        "Email Text": [f"Meeting notes number {i} for the team" for i in range(n)]
                    + [f"Verify your password now number {i} urgent" for i in range(n)],
        "Email Type": ["Safe Email"] * n + ["Phishing Email"] * n,
    })
    path = tmp_path / "alt.csv"
    frame.to_csv(path, index=False)
    data = load_dataset(path)
    assert len(data) == 600


def test_missing_file(tmp_path):
    with pytest.raises(DatasetError, match="not found"):
        load_dataset(tmp_path / "missing.csv")


def test_unknown_columns(tmp_path):
    path = tmp_path / "bad.csv"
    pd.DataFrame({"a": ["x"] * 600, "b": ["y"] * 600}).to_csv(path, index=False)
    with pytest.raises(DatasetError):
        load_dataset(path)
