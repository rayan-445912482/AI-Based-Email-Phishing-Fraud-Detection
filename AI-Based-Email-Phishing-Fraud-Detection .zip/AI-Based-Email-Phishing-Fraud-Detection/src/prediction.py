import time

import joblib

from src.config import MAX_TEXT_LENGTH, MODEL_DISPLAY_NAMES, MODEL_NAMES, MODELS_DIR
from src.preprocessing import clean_text, extract_signal_features, is_valid_text

MODEL_FILES = {name: MODELS_DIR / f"{name}.joblib" for name in MODEL_NAMES}


class ModelNotTrainedError(RuntimeError):
    pass


_cache = {}


def load_model(model_name: str):
    if model_name not in MODEL_FILES:
        raise ValueError(f"Unknown model: {model_name}")
    path = MODEL_FILES[model_name]
    if not path.exists():
        raise ModelNotTrainedError(
            f"Model {model_name} not found. Run: python -m src.training"
        )
    if model_name not in _cache:
        _cache[model_name] = joblib.load(path)
    return _cache[model_name]


def clear_model_cache():
    _cache.clear()


def _phishing_scores(model, texts):
    classes = list(model.classes_)
    probabilities = model.predict_proba(texts)
    return probabilities[:, classes.index("phishing")].tolist()


def predict_email(text: str, model_name: str = "svm", threshold: float = 0.5) -> dict:
    started = time.perf_counter()

    if model_name not in MODEL_FILES:
        raise ValueError(f"Unknown model: {model_name}")
    if not is_valid_text(text, min_length=5, max_length=MAX_TEXT_LENGTH):
        raise ValueError("Email text is empty, too short, or exceeds the length limit.")

    cleaned = clean_text(text)
    model = load_model(model_name)
    score = _phishing_scores(model, [cleaned])[0]
    label = "phishing" if score >= threshold else "legitimate"
    probability = score if label == "phishing" else 1.0 - score

    return {
        "label": label,
        "probability": float(probability),
        "score": float(score),
        "note": "Model probability of the phishing class (not a guarantee).",
        "model": model_name,
        "model_display": MODEL_DISPLAY_NAMES.get(model_name, model_name),
        "features": extract_signal_features(cleaned),
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
    }


def predict_batch(texts: list, model_name: str = "svm", threshold: float = 0.5) -> list:
    model = load_model(model_name)
    cleaned = [clean_text(t) for t in texts]

    valid_idx = [
        i for i, t in enumerate(cleaned)
        if is_valid_text(t, min_length=5, max_length=MAX_TEXT_LENGTH)
    ]

    results = [
        {"label": None, "score": None, "probability": None,
         "error": "Text is empty, too short, or too long."}
        for _ in texts
    ]

    if valid_idx:
        scores = _phishing_scores(model, [cleaned[i] for i in valid_idx])
        for i, score in zip(valid_idx, scores):
            label = "phishing" if score >= threshold else "legitimate"
            results[i] = {
                "label": label,
                "score": float(score),
                "probability": float(score if label == "phishing" else 1.0 - score),
                "error": None,
            }
    return results


def predict_with_all_models(text: str, threshold: float = 0.5) -> dict:
    results = {}
    for model_name in MODEL_NAMES:
        try:
            results[model_name] = predict_email(text, model_name, threshold)
        except ModelNotTrainedError as exc:
            results[model_name] = {"error": str(exc)}
    return results


def consensus_prediction(text: str, threshold: float = 0.5) -> dict:
    per_model = predict_with_all_models(text, threshold)
    valid = {k: v for k, v in per_model.items() if "label" in v}
    if not valid:
        return {"error": "No trained models available.", "per_model": per_model}

    phishing_count = sum(1 for v in valid.values() if v["label"] == "phishing")
    total = len(valid)
    consensus = "phishing" if phishing_count > total / 2 else "legitimate"
    agree = phishing_count if consensus == "phishing" else total - phishing_count

    return {
        "consensus": consensus,
        "confidence": agree / total,
        "votes": {"phishing": phishing_count, "legitimate": total - phishing_count},
        "total_models": total,
        "per_model": per_model,
    }


def models_status() -> dict:
    return {
        name: {
            "trained": MODEL_FILES[name].exists(),
            "path": str(MODEL_FILES[name]),
            "display": MODEL_DISPLAY_NAMES.get(name, name),
        }
        for name in MODEL_NAMES
    }
