import nltk

REQUIRED_PACKAGES = [
    ("tokenizers/punkt", "punkt"),
    ("tokenizers/punkt_tab", "punkt_tab"),
    ("corpora/stopwords", "stopwords"),
    ("corpora/wordnet", "wordnet"),
    ("corpora/omw-1.4", "omw-1.4"),
]


def ensure_nltk_data(force: bool = False) -> list:
    missing = []
    for path, name in REQUIRED_PACKAGES:
        try:
            nltk.data.find(path)
        except LookupError:
            nltk.download(name, quiet=True)
            missing.append(name)
    return missing


def main():
    print("[+] Ensuring NLTK data packages are available ...")
    missing = ensure_nltk_data()
    if missing:
        print(f"[+] Downloaded: {', '.join(missing)}")
    else:
        print("[+] All NLTK packages already present.")
    print("[+] NLTK setup complete.")


if __name__ == "__main__":
    main()
