import numpy as np
from scipy.sparse import hstack, csr_matrix
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline

from src.config import MAX_DF, MAX_FEATURES, MIN_DF, NGRAM_RANGE
from src.preprocessing import clean_and_prepare, extract_signal_features


class SignalFeatures(BaseEstimator, TransformerMixin):
    SIGNAL_KEYS = [
        "length", "word_count", "url_count", "email_count",
        "phone_count", "money_count", "uppercase_ratio",
        "digit_ratio", "exclamation_count", "question_count",
    ]

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        rows = []
        for text in X:
            feats = extract_signal_features(str(text))
            rows.append([float(feats.get(k, 0.0)) for k in self.SIGNAL_KEYS])
        return csr_matrix(np.array(rows, dtype=float))


class CombinedFeatures(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.tfidf = TfidfVectorizer(
            preprocessor=clean_and_prepare,
            ngram_range=NGRAM_RANGE,
            max_features=MAX_FEATURES,
            min_df=MIN_DF,
            max_df=MAX_DF,
            sublinear_tf=True,
            token_pattern=r"(?u)\b\w\w+\b",
        )
        self.signals = SignalFeatures()

    def _configure_tfidf_for_sample_size(self, X):
        # Keep the proposal's stricter thresholds for real datasets, but avoid
        # pruning every token when fitting tiny samples (e.g. unit tests/demo data).
        sample_count = len(X)
        if sample_count < 50:
            self.tfidf.set_params(min_df=1, max_df=1.0)
        else:
            self.tfidf.set_params(min_df=MIN_DF, max_df=MAX_DF)

    def fit(self, X, y=None):
        self._configure_tfidf_for_sample_size(X)
        self.tfidf.fit(X, y)
        self.signals.fit(X, y)
        return self

    def transform(self, X):
        return hstack([self.tfidf.transform(X), self.signals.transform(X)])

    def fit_transform(self, X, y=None, **fit_params):
        self._configure_tfidf_for_sample_size(X)
        self.tfidf.fit(X, y)
        self.signals.fit(X, y)
        return hstack([self.tfidf.transform(X), self.signals.transform(X)])

    def get_feature_names_out(self, input_features=None):
        return self.tfidf.get_feature_names_out()


def build_text_pipeline(classifier) -> Pipeline:
    return Pipeline([
        ("features", CombinedFeatures()),
        ("classifier", classifier),
    ])
