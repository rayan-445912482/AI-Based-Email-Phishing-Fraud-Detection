from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC

from src.config import RANDOM_STATE
from src.features import build_text_pipeline


def build_random_forest():
    return build_text_pipeline(
        RandomForestClassifier(
            n_estimators=150,
            max_depth=60,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )
    )


def build_svm():
    base = LinearSVC(
        C=1.0,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        max_iter=3000,
        dual="auto",
    )
    return build_text_pipeline(
        CalibratedClassifierCV(base, cv=3, method="sigmoid")
    )


def build_naive_bayes():
    return build_text_pipeline(
        MultinomialNB(alpha=0.3, fit_prior=True)
    )


def build_all_models() -> dict:
    return {
        "random_forest": build_random_forest(),
        "svm": build_svm(),
        "naive_bayes": build_naive_bayes(),
    }
