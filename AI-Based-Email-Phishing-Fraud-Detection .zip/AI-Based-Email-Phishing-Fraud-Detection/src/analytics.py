import re
from collections import Counter

import pandas as pd

from src.config import METRICS_FILE, TRAIN_FILE


def metrics_table() -> pd.DataFrame:
    if not METRICS_FILE.exists():
        return pd.DataFrame()
    return pd.read_csv(METRICS_FILE)


def class_balance() -> dict:
    if not TRAIN_FILE.exists():
        return {"legitimate": 0, "phishing": 0}
    frame = pd.read_csv(TRAIN_FILE, usecols=["label"])
    counts = frame["label"].value_counts().to_dict()
    return {
        "legitimate": int(counts.get("legitimate", 0)),
        "phishing": int(counts.get("phishing", 0)),
    }


def text_length_distribution(sample: int = 5000) -> pd.DataFrame:
    if not TRAIN_FILE.exists():
        return pd.DataFrame(columns=["label", "length"])
    frame = pd.read_csv(TRAIN_FILE)
    if len(frame) > sample:
        frame = frame.sample(n=sample, random_state=42)
    frame["length"] = frame["text"].astype(str).str.len()
    return frame[["label", "length"]]


def top_words_per_class(top_n: int = 20) -> pd.DataFrame:
    if not TRAIN_FILE.exists():
        return pd.DataFrame(columns=["label", "word", "count"])
    frame = pd.read_csv(TRAIN_FILE)
    rows = []
    for label in ("legitimate", "phishing"):
        subset = frame[frame["label"] == label]
        counter = Counter()
        for text in subset["text"].astype(str).head(2000):
            counter.update(re.findall(r"[a-zA-Z]{3,}", text.lower()))
        for word, count in counter.most_common(top_n):
            rows.append({"label": label, "word": word, "count": count})
    return pd.DataFrame(rows)


def best_model() -> dict:
    frame = metrics_table()
    if frame.empty:
        return {}
    return frame.sort_values("f1_score", ascending=False).iloc[0].to_dict()
