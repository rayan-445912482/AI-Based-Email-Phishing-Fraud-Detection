import json
from datetime import datetime, timezone

import joblib
import pandas as pd
from sklearn.model_selection import cross_val_score, train_test_split

from src.config import (
    CV_FOLDS,
    DEFAULT_DATASET,
    METADATA_FILE,
    METRICS_FILE,
    MODEL_NAMES,
    MODELS_DIR,
    PROCESSED_DATA_DIR,
    RANDOM_STATE,
    RESULTS_DIR,
    TEST_FILE,
    TEST_SIZE,
    TRAIN_FILE,
)
from src.data_loader import load_dataset
from src.error_analysis import run_error_analysis
from src.evaluation import (
    calculate_metrics,
    compare_models,
    save_all_charts,
    save_classification_report,
)
from src.logger import logger
from src.models import build_all_models


def get_phishing_scores(model, texts):
    classes = list(model.classes_)
    if "phishing" not in classes:
        return None
    return model.predict_proba(texts)[:, classes.index("phishing")]


def prepare_datasets(dataset_path=DEFAULT_DATASET):
    logger.info("Preparing datasets")
    data = load_dataset(dataset_path)

    PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)

    train_data, test_data = train_test_split(
        data,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=data["label"],
    )

    train_data.to_csv(TRAIN_FILE, index=False)
    test_data.to_csv(TEST_FILE, index=False)

    logger.info(f"Train: {len(train_data):,} | Test: {len(test_data):,}")
    return train_data, test_data, data


def evaluate_model(model_name, model, X_test, y_test):
    logger.info(f"Evaluating {model_name}")
    predictions = model.predict(X_test)
    scores = get_phishing_scores(model, X_test)
    metrics = calculate_metrics(y_test, predictions, scores)
    save_classification_report(model_name, y_test, predictions)
    save_all_charts(model_name, y_test, predictions, scores)
    logger.info(
        f"{model_name} | Acc={metrics['accuracy']:.4f} "
        f"P={metrics['precision']:.4f} R={metrics['recall']:.4f} "
        f"F1={metrics['f1_score']:.4f}"
    )
    return metrics, list(predictions), (list(scores) if scores is not None else None)


def cross_validate_model(model, X_train, y_train):
    try:
        scores = cross_val_score(
            model, X_train, y_train,
            cv=CV_FOLDS, scoring="f1_macro", n_jobs=1,
        )
        return {
            "mean_f1_macro": float(scores.mean()),
            "std_f1_macro": float(scores.std()),
            "folds": [float(s) for s in scores],
        }
    except Exception as exc:
        logger.warning(f"Cross-validation failed: {exc}")
        return None


def run_training(dataset_path=DEFAULT_DATASET, run_cv: bool = True) -> pd.DataFrame:
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    train_data, test_data, full_data = prepare_datasets(dataset_path)

    X_train, y_train = train_data["text"], train_data["label"]
    X_test, y_test = test_data["text"], test_data["label"]

    models = build_all_models()
    results = []
    all_predictions = {}

    metadata = {
        "app_version": "2.0.0",
        "trained_at_utc": datetime.now(timezone.utc).isoformat(),
        "dataset_path": str(dataset_path),
        "total_rows": int(len(full_data)),
        "train_rows": int(len(train_data)),
        "test_rows": int(len(test_data)),
        "random_state": RANDOM_STATE,
        "test_size": TEST_SIZE,
        "positive_class": "phishing",
        "uses_nltk": True,
        "uses_signal_features": True,
        "class_distribution": {
            str(k): int(v) for k, v in full_data["label"].value_counts().items()
        },
        "models": {},
    }

    for model_name in MODEL_NAMES:
        model = models[model_name]
        cv_result = cross_validate_model(model, X_train, y_train) if run_cv else None

        logger.info(f"Training {model_name}")
        model.fit(X_train, y_train)

        metrics, predictions, scores = evaluate_model(model_name, model, X_test, y_test)

        model_path = MODELS_DIR / f"{model_name}.joblib"
        joblib.dump(model, model_path, compress=3)

        all_predictions[model_name] = {
            "predictions": predictions,
            "scores": scores,
        }

        results.append({"model": model_name, **metrics})
        metadata["models"][model_name] = {
            "artifact": model_path.name,
            "metrics": metrics,
            "cross_validation": cv_result,
        }

    metrics_frame = compare_models(results)
    metrics_frame.to_csv(METRICS_FILE, index=False)
    metadata["best_model_by_f1"] = str(metrics_frame.iloc[0]["model"])
    METADATA_FILE.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    try:
        run_error_analysis(all_predictions)
    except Exception as exc:
        logger.warning(f"Error analysis failed: {exc}")

    logger.info("Training complete")
    logger.info("\n" + metrics_frame.to_string(index=False))
    return metrics_frame


if __name__ == "__main__":
    run_training()
