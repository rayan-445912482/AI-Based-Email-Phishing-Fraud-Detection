import json

import pandas as pd

from src.config import ERROR_ANALYSIS_DIR, MODEL_NAMES, TEST_FILE
from src.logger import logger


def load_test_set():
    if not TEST_FILE.exists():
        return pd.DataFrame()
    return pd.read_csv(TEST_FILE)


def analyze_errors(model_name: str, predictions: list, scores: list = None) -> dict:
    test = load_test_set()
    if test.empty:
        return {"error": "Test set not found."}

    n = min(len(test), len(predictions))
    df = test.iloc[:n].copy()
    df["predicted"] = predictions[:n]
    df["score"] = scores[:n] if scores is not None else None

    df["correct"] = df["label"] == df["predicted"]
    errors = df[~df["correct"]].copy()
    false_positives = errors[errors["predicted"] == "phishing"]
    false_negatives = errors[errors["predicted"] == "legitimate"]

    ERROR_ANALYSIS_DIR.mkdir(parents=True, exist_ok=True)

    if not errors.empty:
        errors_sorted = errors.sort_values("score", ascending=False, na_position="last").head(50)
        errors_sorted.to_csv(ERROR_ANALYSIS_DIR / f"{model_name}_errors.csv", index=False)

    summary = {
        "model": model_name,
        "total_test": int(len(df)),
        "correct": int(df["correct"].sum()),
        "errors": int(len(errors)),
        "false_positives": int(len(false_positives)),
        "false_negatives": int(len(false_negatives)),
        "examples": [],
    }

    for _, row in false_positives.head(5).iterrows():
        summary["examples"].append({
            "type": "false_positive",
            "text": str(row["text"])[:300],
            "true_label": row["label"],
            "predicted": row["predicted"],
        })

    for _, row in false_negatives.head(5).iterrows():
        summary["examples"].append({
            "type": "false_negative",
            "text": str(row["text"])[:300],
            "true_label": row["label"],
            "predicted": row["predicted"],
        })

    (ERROR_ANALYSIS_DIR / f"{model_name}_summary.json").write_text(
        json.dumps(summary, indent=2, default=str), encoding="utf-8"
    )
    return summary


def run_error_analysis(all_predictions: dict) -> dict:
    summaries = {}
    for model_name in MODEL_NAMES:
        if model_name not in all_predictions:
            continue
        data = all_predictions[model_name]
        summaries[model_name] = analyze_errors(
            model_name,
            data.get("predictions", []),
            data.get("scores"),
        )
    logger.info("Error analysis complete")
    return summaries


def load_error_summary(model_name: str) -> dict:
    path = ERROR_ANALYSIS_DIR / f"{model_name}_summary.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))
