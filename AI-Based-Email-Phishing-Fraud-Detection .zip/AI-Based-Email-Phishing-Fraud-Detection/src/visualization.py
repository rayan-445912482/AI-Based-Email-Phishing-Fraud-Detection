import json

import pandas as pd

from src.config import METADATA_FILE, METRICS_FILE, MODEL_NAMES, MODELS_DIR


def load_metrics() -> pd.DataFrame:
    if not METRICS_FILE.exists():
        return pd.DataFrame()
    return pd.read_csv(METRICS_FILE)


def load_metadata() -> dict:
    if not METADATA_FILE.exists():
        return {}
    return json.loads(METADATA_FILE.read_text(encoding="utf-8"))


def available_models() -> list:
    return [n for n in MODEL_NAMES if (MODELS_DIR / f"{n}.joblib").exists()]
