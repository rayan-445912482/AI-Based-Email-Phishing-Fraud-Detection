import html
import re
import unicodedata

from src.config import USE_NLTK

try:
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    from nltk.tokenize import word_tokenize
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False


PHISHING_LABELS = {
    "phishing", "phish", "phishing email", "fraud", "fraudulent",
    "malicious", "1", "true", "yes", "suspicious", "attack",
}

LEGITIMATE_LABELS = {
    "legitimate", "legit", "safe", "safe email", "ham", "benign",
    "normal", "0", "false", "no", "genuine",
    "non-phishing", "nonphishing",
}

URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
EMAIL_PATTERN = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
PHONE_PATTERN = re.compile(r"\b(?:\+?\d[\d\s\-()]{7,}\d)\b")
MONEY_PATTERN = re.compile(r"[$€£]\s?\d+(?:[.,]\d+)?")
HTML_TAG = re.compile(r"<[^>]{1,500}>")
MULTI_SPACE = re.compile(r"\s+")

_STOPWORDS = None
_LEMMATIZER = None


def _get_stopwords():
    global _STOPWORDS
    if _STOPWORDS is None:
        try:
            _STOPWORDS = set(stopwords.words("english"))
        except Exception:
            _STOPWORDS = set()
    return _STOPWORDS


def _get_lemmatizer():
    global _LEMMATIZER
    if _LEMMATIZER is None:
        try:
            _LEMMATIZER = WordNetLemmatizer()
        except Exception:
            _LEMMATIZER = None
    return _LEMMATIZER


def normalize_label(value):
    if value is None:
        return None
    try:
        if value != value:
            return None
    except Exception:
        return None

    label = unicodedata.normalize("NFKC", str(value)).strip().lower()
    label = MULTI_SPACE.sub(" ", label)

    if label in {"1.0"}:
        label = "1"
    if label in {"0.0"}:
        label = "0"

    if label in PHISHING_LABELS:
        return "phishing"
    if label in LEGITIMATE_LABELS:
        return "legitimate"
    return None


def clean_text(value) -> str:
    if value is None:
        return ""

    text = html.unescape(str(value))
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\x00", " ")

    text = re.sub(r"<\s*br\s*/?\s*>", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/?\s*p\s*>", " ", text, flags=re.IGNORECASE)
    text = HTML_TAG.sub(" ", text)
    text = MULTI_SPACE.sub(" ", text)

    return text.strip()


def nltk_preprocess(text: str) -> str:
    if not USE_NLTK or not NLTK_AVAILABLE or not text:
        return text.lower()

    try:
        tokens = word_tokenize(text.lower())
    except Exception:
        tokens = text.lower().split()

    stops = _get_stopwords()
    lemma = _get_lemmatizer()

    processed = []
    for token in tokens:
        if not token.isalpha():
            continue
        if token in stops:
            continue
        if lemma is not None:
            try:
                token = lemma.lemmatize(token)
            except Exception:
                pass
        processed.append(token)

    return " ".join(processed)


def clean_and_prepare(value) -> str:
    cleaned = clean_text(value)
    return nltk_preprocess(cleaned)


def extract_signal_features(text: str) -> dict:
    text = text or ""
    n = max(len(text), 1)
    return {
        "length": len(text),
        "word_count": len(text.split()),
        "url_count": len(URL_PATTERN.findall(text)),
        "email_count": len(EMAIL_PATTERN.findall(text)),
        "phone_count": len(PHONE_PATTERN.findall(text)),
        "money_count": len(MONEY_PATTERN.findall(text)),
        "uppercase_ratio": sum(1 for c in text if c.isupper()) / n,
        "digit_ratio": sum(1 for c in text if c.isdigit()) / n,
        "exclamation_count": text.count("!"),
        "question_count": text.count("?"),
    }


def is_valid_text(text, min_length: int = 10, max_length: int = 100_000) -> bool:
    if not text or not isinstance(text, str):
        return False
    length = len(text.strip())
    return min_length <= length <= max_length
