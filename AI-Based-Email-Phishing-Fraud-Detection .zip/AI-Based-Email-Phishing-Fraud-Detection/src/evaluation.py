import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.metrics import (
    accuracy_score,
    auc,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)

from src.config import CHARTS_DIR, MATRICES_DIR, MODEL_DISPLAY_NAMES, REPORTS_DIR

CLASS_LABELS = ["legitimate", "phishing"]


def _binary(y_true):
    return [1 if v == "phishing" else 0 for v in y_true]


def calculate_metrics(y_true, y_pred, y_score=None) -> dict:
    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, pos_label="phishing", zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, pos_label="phishing", zero_division=0)),
        "f1_score": float(f1_score(y_true, y_pred, pos_label="phishing", zero_division=0)),
        "roc_auc": None,
    }
    if y_score is not None:
        try:
            metrics["roc_auc"] = float(roc_auc_score(_binary(y_true), y_score))
        except (ValueError, TypeError):
            metrics["roc_auc"] = None
    return metrics


def _name(model_name):
    return MODEL_DISPLAY_NAMES.get(model_name, model_name)


def save_confusion_matrix(model_name, y_true, y_pred):
    MATRICES_DIR.mkdir(parents=True, exist_ok=True)
    matrix = confusion_matrix(y_true, y_pred, labels=CLASS_LABELS)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        matrix, annot=True, fmt="d", cmap="Blues",
        xticklabels=CLASS_LABELS, yticklabels=CLASS_LABELS, ax=ax,
        annot_kws={"size": 14, "weight": "bold"},
    )
    ax.set_xlabel("Predicted", fontsize=12, fontweight="bold")
    ax.set_ylabel("Actual", fontsize=12, fontweight="bold")
    ax.set_title(f"Confusion Matrix - {_name(model_name)}", fontsize=13, fontweight="bold", pad=12)
    fig.tight_layout()
    path = MATRICES_DIR / f"{model_name}.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def save_roc_curve(model_name, y_true, y_score):
    if y_score is None:
        return None
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    fpr, tpr, _ = roc_curve(_binary(y_true), y_score)
    roc_auc = auc(fpr, tpr)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="#2563eb", lw=2.5, label=f"AUC = {roc_auc:.4f}")
    ax.plot([0, 1], [0, 1], color="#94a3b8", lw=1.5, linestyle="--", label="Baseline")
    ax.fill_between(fpr, tpr, alpha=0.15, color="#2563eb")
    ax.set_xlabel("False Positive Rate", fontsize=12, fontweight="bold")
    ax.set_ylabel("True Positive Rate", fontsize=12, fontweight="bold")
    ax.set_title(f"ROC Curve - {_name(model_name)}", fontsize=13, fontweight="bold", pad=12)
    ax.legend(loc="lower right", fontsize=11)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    path = CHARTS_DIR / f"roc_{model_name}.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def save_pr_curve(model_name, y_true, y_score):
    if y_score is None:
        return None
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    precision, recall, _ = precision_recall_curve(_binary(y_true), y_score)
    pr_auc = auc(recall, precision)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(recall, precision, color="#16a34a", lw=2.5, label=f"AUC = {pr_auc:.4f}")
    ax.fill_between(recall, precision, alpha=0.15, color="#16a34a")
    ax.set_xlabel("Recall", fontsize=12, fontweight="bold")
    ax.set_ylabel("Precision", fontsize=12, fontweight="bold")
    ax.set_title(f"Precision-Recall - {_name(model_name)}", fontsize=13, fontweight="bold", pad=12)
    ax.legend(loc="lower left", fontsize=11)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    path = CHARTS_DIR / f"pr_{model_name}.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def save_all_charts(model_name, y_true, y_pred, y_score=None):
    paths = {"confusion": save_confusion_matrix(model_name, y_true, y_pred)}
    if y_score is not None:
        paths["roc"] = save_roc_curve(model_name, y_true, y_score)
        paths["pr"] = save_pr_curve(model_name, y_true, y_score)
    return paths


def save_classification_report(model_name, y_true, y_pred) -> dict:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    report = classification_report(
        y_true, y_pred, labels=CLASS_LABELS,
        output_dict=True, zero_division=0,
    )
    path = REPORTS_DIR / f"{model_name}.json"
    path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def compare_models(metrics_list) -> pd.DataFrame:
    frame = pd.DataFrame(metrics_list)
    return frame.sort_values("f1_score", ascending=False).reset_index(drop=True)
