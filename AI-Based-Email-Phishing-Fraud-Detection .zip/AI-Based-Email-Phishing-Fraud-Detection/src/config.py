from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

MODELS_DIR = PROJECT_ROOT / "models"
RESULTS_DIR = PROJECT_ROOT / "results"
CHARTS_DIR = RESULTS_DIR / "charts"
REPORTS_DIR = RESULTS_DIR / "reports"
MATRICES_DIR = RESULTS_DIR / "matrices"
ERROR_ANALYSIS_DIR = RESULTS_DIR / "error_analysis"
ASSETS_DIR = PROJECT_ROOT / "assets"
LOGS_DIR = PROJECT_ROOT / "logs"
DATABASE_DIR = PROJECT_ROOT / "database"
DATABASE_FILE = DATABASE_DIR / "analyses.db"

DEFAULT_DATASET = RAW_DATA_DIR / "emails.csv"
TRAIN_FILE = PROCESSED_DATA_DIR / "train.csv"
TEST_FILE = PROCESSED_DATA_DIR / "test.csv"
METRICS_FILE = RESULTS_DIR / "metrics.csv"
METADATA_FILE = MODELS_DIR / "metadata.json"

TEXT_COLUMN = "text"
LABEL_COLUMN = "label"

TEST_SIZE = 0.20
RANDOM_STATE = 42
CV_FOLDS = 3

MIN_ROWS = 500
MIN_PER_CLASS = 200
MAX_TEXT_LENGTH = 100_000
MAX_FEATURES = 50_000
NGRAM_RANGE = (1, 2)
MIN_DF = 2
MAX_DF = 0.95

USE_NLTK = True

MODEL_NAMES = ["random_forest", "svm", "naive_bayes"]

MODEL_DISPLAY_NAMES = {
    "random_forest": "Random Forest",
    "svm": "Support Vector Machine",
    "naive_bayes": "Naive Bayes",
}

MODEL_DESCRIPTIONS = {
    "random_forest": "Ensemble of decision trees with class balancing",
    "svm": "Linear SVM with probability calibration",
    "naive_bayes": "Multinomial Naive Bayes baseline",
}

APP_TITLE = "AI-Based Email Phishing & Fraud Detection"
APP_SUBTITLE = "Graduation Project · King Saud University"
APP_VERSION = "2.0.0"

SUPERVISOR = "DR. FAHAD ALOTAIBI"

GROUP_MEMBERS = [
    {
        "id": 1,
        "name": "RAYAN ABDULRAHMAN IBRAHIM ALHIRABI",
        "tasks": [
            "Requirements analysis and project planning",
            "Dataset research and preparation",
            "Coordination of project stages",
            "Documentation of project requirements and analysis",
        ],
    },
    {
        "id": 2,
        "name": "ALI ASAAD A ALSUWAYRI",
        "tasks": [
            "Backend development",
            "API and system logic development",
            "Database design and management",
            "Integration of the trained AI models with the backend",
        ],
    },
    {
        "id": 3,
        "name": "ABDULELAH FAHAD HAJRS ALOTAIBI",
        "tasks": [
            "AI model development",
            "Implementation of the Random Forest model",
            "Data preprocessing and feature extraction",
            "Model training and performance evaluation",
        ],
    },
    {
        "id": 4,
        "name": "HUSSAM MOHAMMED ALMUTAIRI",
        "tasks": [
            "AI model development",
            "Implementation of the SVM and Naive Bayes models",
            "Model testing and comparison",
            "Analysis of classification performance",
        ],
    },
    {
        "id": 5,
        "name": "Faisal Turki Mohammed Alshebaiki",
        "tasks": [
            "User interface design and development",
            "Streamlit prototype development",
            "System integration and usability testing",
            "Preparation of demonstrations and final presentation materials",
        ],
    },
    {
        "id": 6,
        "name": "FAHAD MUSAAD ALOTAIBI",
        "tasks": [
            "Dataset validation and organization",
            "Email data analysis and labeling",
            "Support in model testing and evaluation",
            "Documentation and testing support",
        ],
    },
]
