import pandas as pd

from src.config import (
    DEFAULT_DATASET,
    LABEL_COLUMN,
    MIN_PER_CLASS,
    MIN_ROWS,
    TEXT_COLUMN,
)
from src.logger import logger
from src.preprocessing import clean_text, is_valid_text, normalize_label


class DatasetError(ValueError):
    pass


TEXT_CANDIDATES = (
    "text", "email", "message", "body", "content",
    "email_text", "text_combined", "email text",
)
LABEL_CANDIDATES = (
    "label", "class", "category", "target", "type",
    "email_type", "email type",
)


def _find_column(columns, configured, candidates, kind):
    lookup = {str(c).strip().lower(): c for c in columns}
    if configured and configured.lower() in lookup:
        return lookup[configured.lower()]
    for candidate in candidates:
        if candidate in lookup:
            return lookup[candidate]
    raise DatasetError(
        f"Could not identify the {kind} column. "
        f"Expected one of: {', '.join(candidates)}. "
        f"Available: {list(columns)}"
    )


def load_dataset(
    path=DEFAULT_DATASET,
    text_column=TEXT_COLUMN,
    label_column=LABEL_COLUMN,
    min_rows=MIN_ROWS,
    min_per_class=MIN_PER_CLASS,
) -> pd.DataFrame:
    path = str(path)
    logger.info(f"Loading dataset from {path}")

    try:
        frame = pd.read_csv(path, low_memory=False)
    except FileNotFoundError as exc:
        raise DatasetError(
            f"Dataset not found: {path}. Run: python download_data.py"
        ) from exc
    except (pd.errors.ParserError, UnicodeDecodeError, OSError) as exc:
        raise DatasetError(f"Could not read dataset: {exc}") from exc

    if frame.empty:
        raise DatasetError("The dataset is empty.")

    text_col = _find_column(frame.columns, text_column, TEXT_CANDIDATES, "text")
    label_col = _find_column(frame.columns, label_column, LABEL_CANDIDATES, "label")

    if text_col == label_col:
        raise DatasetError("Text and label columns must be different.")

    data = frame[[text_col, label_col]].copy()
    data.columns = ["text", "label"]
    data["text"] = data["text"].fillna("").astype(str).map(clean_text)
    data["label"] = data["label"].map(normalize_label)

    data = data[data["text"].map(is_valid_text) & data["label"].notna()]

    before = len(data)
    data = data.drop_duplicates(subset=["text"]).reset_index(drop=True)
    logger.info(f"Dropped {before - len(data):,} duplicate rows")

    if len(data) < min_rows:
        raise DatasetError(
            f"Only {len(data)} valid rows after cleaning; minimum is {min_rows}."
        )

    counts = data["label"].value_counts()
    for label in ("legitimate", "phishing"):
        if counts.get(label, 0) < min_per_class:
            raise DatasetError(
                f"Class {label!r} has {counts.get(label, 0)} rows; "
                f"minimum is {min_per_class}."
            )

    logger.info(
        f"Loaded {len(data):,} rows | "
        f"{data['label'].value_counts().to_dict()}"
    )
    return data


def get_dataset_stats(path=DEFAULT_DATASET) -> dict:
    try:
        data = load_dataset(path)
    except DatasetError as exc:
        return {"error": str(exc), "loaded": False}

    counts = data["label"].value_counts().to_dict()
    lengths = data["text"].str.len()

    return {
        "loaded": True,
        "total_rows": int(len(data)),
        "legitimate": int(counts.get("legitimate", 0)),
        "phishing": int(counts.get("phishing", 0)),
        "avg_length": float(lengths.mean()),
        "min_length": int(lengths.min()),
        "max_length": int(lengths.max()),
        "path": str(path),
    }
