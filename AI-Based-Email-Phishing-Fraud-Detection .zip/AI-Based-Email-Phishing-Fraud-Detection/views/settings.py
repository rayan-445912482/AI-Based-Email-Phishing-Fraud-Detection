import streamlit as st

from src.config import (
    APP_VERSION,
    CV_FOLDS,
    MAX_FEATURES,
    MODEL_DISPLAY_NAMES,
    MODEL_NAMES,
    NGRAM_RANGE,
    RANDOM_STATE,
    TEST_SIZE,
    USE_NLTK,
)
from src.data_loader import get_dataset_stats
from src.prediction import clear_model_cache, models_status


def render():
    st.markdown(
        """
        <div class="hero">
            <h1>Settings</h1>
            <p>Configuration and system information</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    tab1, tab2, tab3, tab4 = st.tabs(
        ["Model Configuration", "System Info", "Data Status", "Database"]
    )

    with tab1:
        st.markdown("### Current Configuration")
        c1, c2 = st.columns(2)
        with c1:
            st.markdown(
                f'<div class="info-box">'
                f"<strong>Random State:</strong> {RANDOM_STATE}<br>"
                f"<strong>Test Size:</strong> {TEST_SIZE}<br>"
                f"<strong>CV Folds:</strong> {CV_FOLDS}<br>"
                f"<strong>Max Features:</strong> {MAX_FEATURES:,}</div>",
                unsafe_allow_html=True,
            )
        with c2:
            st.markdown(
                f'<div class="info-box">'
                f"<strong>N-Gram Range:</strong> {NGRAM_RANGE}<br>"
                f"<strong>NLTK Enabled:</strong> {'Yes' if USE_NLTK else 'No'}<br>"
                f"<strong>Models:</strong> {len(MODEL_NAMES)}<br>"
                f"<strong>Version:</strong> {APP_VERSION}</div>",
                unsafe_allow_html=True,
            )

        st.markdown("### Model Status")
        status = models_status()
        for name, info in status.items():
            display = MODEL_DISPLAY_NAMES.get(name, name)
            icon = "✅" if info["trained"] else "❌"
            label = "Trained" if info["trained"] else "Not trained"
            st.markdown(f"{icon} **{display}** — {label}")

        if st.button("Clear Model Cache"):
            clear_model_cache()
            st.success("Model cache cleared.")

    with tab2:
        st.markdown("### System Information")
        st.markdown(
            f"""
            | Property | Value |
            |----------|-------|
            | Application | AI-Based Email Phishing & Fraud Detection |
            | Version | {APP_VERSION} |
            | Python | 3.12+ |
            | Framework | Streamlit |
            | ML Library | scikit-learn |
            | NLP Library | NLTK |
            | Visualization | Plotly + Matplotlib |
            | Database | SQLite |
            """
        )

    with tab3:
        st.markdown("### Dataset Status")
        stats = get_dataset_stats()

        if stats.get("loaded"):
            c1, c2 = st.columns(2)
            with c1:
                st.metric("Total Rows", f"{stats['total_rows']:,}")
                st.metric("Legitimate", f"{stats['legitimate']:,}")
            with c2:
                st.metric("Phishing", f"{stats['phishing']:,}")
                st.metric("Average Length", f"{stats['avg_length']:,.0f}")
            st.markdown(f"**Path:** `{stats['path']}`")
            if st.button("Reload Dataset", use_container_width=True):
                st.cache_data.clear()
                st.rerun()
        else:
            st.warning(stats.get("error", "Dataset not loaded."))
            st.code("python download_data.py", language="bash")

    with tab4:
        st.markdown("### Analysis Database (SQLite)")
        st.markdown(
            "Every analysis performed in the **Analyzer** page is logged to "
            "`database/analyses.db` by the `database/db.py` module "
            "(Member 2 responsibility: database design and management)."
        )
        try:
            from database.db import fetch_analysis_stats, fetch_recent_analyses
            stats = fetch_analysis_stats()
            c1, c2, c3 = st.columns(3)
            c1.metric("Total Analyses", stats.get("total", 0))
            c2.metric("Phishing", stats.get("phishing", 0))
            c3.metric("Legitimate", stats.get("legitimate", 0))

            rows = fetch_recent_analyses(limit=20)
            if rows:
                import pandas as pd
                st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
            else:
                st.info("No analyses yet.")
        except Exception as exc:
            st.warning(f"Database not initialized: {exc}")
