import streamlit as st

from src.config import APP_SUBTITLE, APP_TITLE, APP_VERSION, SUPERVISOR
from src.data_loader import get_dataset_stats
from src.prediction import models_status
from src.visualization import load_metadata, load_metrics


@st.cache_data(show_spinner=False)
def _cached_stats():
    return get_dataset_stats()


def _card(label, value, small=False):
    size = "1.25rem" if small else "2rem"
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">{label}</div>
            <div class="metric-value" style="font-size:{size};">{value}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render():
    st.markdown(
        f"""
        <div class="hero">
            <h1>🛡️ {APP_TITLE}</h1>
            <p>{APP_SUBTITLE} · v{APP_VERSION}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("## Platform Overview")
    st.markdown(
        "AI-Based Email Phishing & Fraud Detection detects phishing emails from "
        "their text using supervised machine learning. The project implements "
        "three independent classifiers (Random Forest, Support Vector Machine, "
        "and Naive Bayes) trained on the same prepared dataset and evaluated with "
        "the same metrics, as specified in the graduation project proposal."
    )

    st.markdown("## System Status")
    status = models_status()
    trained = sum(1 for s in status.values() if s["trained"])
    dataset = _cached_stats()
    metadata = load_metadata()
    metrics = load_metrics()

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        _card("Models Trained", f"{trained}/3")
    with c2:
        rows = dataset.get("total_rows", 0) if dataset.get("loaded") else 0
        _card("Dataset Rows", f"{rows:,}")
    with c3:
        _card("Best Model", metadata.get("best_model_by_f1", "N/A"), small=True)
    with c4:
        best_f1 = metrics.iloc[0]["f1_score"] if not metrics.empty else 0
        _card("Best F1-Score", f"{best_f1:.4f}")

    st.markdown("## Proposal Alignment")
    st.markdown(
        """
        | Proposal Requirement | Status |
        |----------------------|--------|
        | Three AI models (RF, SVM, NB) | ✅ |
        | TF-IDF features | ✅ |
        | NLTK preprocessing | ✅ |
        | Accuracy / Precision / Recall / F1 | ✅ |
        | Interactive Streamlit prototype | ✅ |
        | Model comparison | ✅ |
        | Error analysis | ✅ |
        | Jupyter Notebook experiment | ✅ |
        | Database for analyses | ✅ |
        """
    )

    st.markdown("## Project Stages")
    st.markdown(
        """
        1. **Requirements and Project Analysis** — Scope, functions, evaluation criteria.
        2. **Dataset Collection and Preparation** — Real labeled dataset, cleaned.
        3. **Data Preprocessing and Feature Extraction** — NLTK + TF-IDF + signals.
        4. **AI Model Development** — Three classifiers implemented.
        5. **Model Training and Evaluation** — Train/test split + metrics.
        6. **System Development and Integration** — Streamlit + SQLite.
        7. **Testing, Comparison, and Documentation** — Tests, comparison, errors.
        """
    )

    st.markdown("## Supervisor")
    st.markdown(f"**{SUPERVISOR}**")

    st.markdown(
        f'<div class="footer">AI-Based Email Phishing & Fraud Detection · v{APP_VERSION}</div>',
        unsafe_allow_html=True,
    )
