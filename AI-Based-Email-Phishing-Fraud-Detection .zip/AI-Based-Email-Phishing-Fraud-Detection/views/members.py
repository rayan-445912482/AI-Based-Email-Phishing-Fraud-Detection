import streamlit as st

from src.config import GROUP_MEMBERS, SUPERVISOR


def render():
    st.markdown(
        """
        <div class="hero">
            <h1>Group Members & Tasks</h1>
            <p>Distribution of responsibilities as stated in the proposal</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown('<div class="section-title">Supervisor</div>', unsafe_allow_html=True)
    st.markdown(
        f"""
        <div class="member-card">
            <span class="member-id">S1</span>
            <span class="member-name">{SUPERVISOR}</span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown('<div class="section-title">Students</div>', unsafe_allow_html=True)

    for member in GROUP_MEMBERS:
        tasks_html = "".join(f"<li>{t}</li>" for t in member["tasks"])
        st.markdown(
            f"""
            <div class="member-card">
                <span class="member-id">#{member['id']}</span>
                <span class="member-name">{member['name']}</span>
                <ul class="member-tasks">{tasks_html}</ul>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown('<div class="section-title">Shared Responsibilities</div>', unsafe_allow_html=True)
    st.markdown(
        "All group members participate in dataset review, system testing, "
        "documentation, research, troubleshooting, final evaluation, and the "
        "project presentation."
    )
