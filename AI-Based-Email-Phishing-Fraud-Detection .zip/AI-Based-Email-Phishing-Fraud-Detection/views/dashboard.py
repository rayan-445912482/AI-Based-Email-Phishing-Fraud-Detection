import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src.analytics import (
    best_model,
    class_balance,
    metrics_table,
    text_length_distribution,
    top_words_per_class,
)
from src.data_loader import get_dataset_stats


@st.cache_data(show_spinner=False)
def _cached_stats():
    return get_dataset_stats()


@st.cache_data(show_spinner=False)
def _cached_balance():
    return class_balance()


@st.cache_data(show_spinner=False)
def _cached_distribution():
    return text_length_distribution(sample=5000)


@st.cache_data(show_spinner=False)
def _cached_words():
    return top_words_per_class(top_n=15)


def render():
    st.markdown(
        """
        <div class="hero">
            <h1>Analytics Dashboard</h1>
            <p>Data distribution, model performance, and content analytics</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    stats = _cached_stats()
    if not stats.get("loaded"):
        st.warning("No dataset loaded. Run `python download_data.py` first.")
        return

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Emails", f"{stats['total_rows']:,}")
    c2.metric("Legitimate", f"{stats['legitimate']:,}")
    c3.metric("Phishing", f"{stats['phishing']:,}")
    c4.metric("Avg Length", f"{stats['avg_length']:,.0f}")

    st.markdown('<div class="section-title">Class Distribution</div>', unsafe_allow_html=True)
    balance = _cached_balance()

    fig = go.Figure(data=[
        go.Bar(
            x=["Legitimate", "Phishing"],
            y=[balance["legitimate"], balance["phishing"]],
            marker_color=["#16a34a", "#dc2626"],
            text=[balance["legitimate"], balance["phishing"]],
            textposition="auto",
        )
    ])
    fig.update_layout(
        height=400, showlegend=False,
        margin=dict(l=20, r=20, t=20, b=20),
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
    )
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="section-title">Text Length Distribution</div>', unsafe_allow_html=True)
    dist = _cached_distribution()

    if not dist.empty:
        fig = px.histogram(
            dist, x="length", color="label", nbins=50,
            color_discrete_map={"legitimate": "#16a34a", "phishing": "#dc2626"},
            barmode="overlay", opacity=0.7,
        )
        fig.update_layout(
            height=400,
            margin=dict(l=20, r=20, t=20, b=20),
            plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Email Length (characters)", yaxis_title="Count",
        )
        st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="section-title">Top Words per Class</div>', unsafe_allow_html=True)
    words = _cached_words()

    if not words.empty:
        col1, col2 = st.columns(2)
        for idx, label in enumerate(["legitimate", "phishing"]):
            subset = words[words["label"] == label].sort_values("count", ascending=True)
            color = "#16a34a" if label == "legitimate" else "#dc2626"
            fig = go.Figure(data=[
                go.Bar(x=subset["count"], y=subset["word"], orientation="h", marker_color=color)
            ])
            fig.update_layout(
                title=f"Top {label.title()} Words", height=500,
                margin=dict(l=20, r=20, t=40, b=20),
                plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
                xaxis_title="Frequency",
            )
            with (col1 if idx == 0 else col2):
                st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="section-title">Model Performance</div>', unsafe_allow_html=True)
    metrics = metrics_table()

    if metrics.empty:
        st.info("Train the models to see performance metrics.")
        return

    best = best_model()
    if best:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-label">Best Model</div>
                <div class="metric-value">{best['model']}</div>
                <p style="color:#64748b;margin:0.5rem 0 0 0;">
                    F1: {best['f1_score']:.4f} · Acc: {best['accuracy']:.4f}
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("### Metrics Table")
    display_cols = ["model", "accuracy", "precision", "recall", "f1_score", "roc_auc"]
    display_cols = [c for c in display_cols if c in metrics.columns]
    st.dataframe(
        metrics[display_cols].style.format({
            c: "{:.4f}" for c in display_cols if c != "model"
        }),
        use_container_width=True, hide_index=True,
    )

    st.markdown("### Metrics Comparison")
    chart_metrics = ["accuracy", "precision", "recall", "f1_score"]
    chart_metrics = [c for c in chart_metrics if c in metrics.columns]

    fig = go.Figure()
    colors = {"random_forest": "#2563eb", "svm": "#16a34a", "naive_bayes": "#f59e0b"}
    for _, row in metrics.iterrows():
        fig.add_trace(go.Bar(
            name=row["model"],
            x=[m.replace("_", " ").title() for m in chart_metrics],
            y=[row[m] for m in chart_metrics],
            marker_color=colors.get(row["model"], "#64748b"),
            text=[f"{row[m]:.4f}" for m in chart_metrics],
            textposition="auto",
        ))

    fig.update_layout(
        barmode="group", height=450,
        margin=dict(l=20, r=20, t=20, b=20),
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        yaxis=dict(range=[
            max(0.0, metrics[chart_metrics].min().min() - 0.05),
            min(1.0, metrics[chart_metrics].max().max() + 0.02),
        ]),
    )
    st.plotly_chart(fig, use_container_width=True)
