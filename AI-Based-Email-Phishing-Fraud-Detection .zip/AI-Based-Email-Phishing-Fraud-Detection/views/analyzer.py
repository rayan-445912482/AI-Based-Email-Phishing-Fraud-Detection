import streamlit as st

from src.config import MODEL_DISPLAY_NAMES, MODEL_NAMES
from src.prediction import ModelNotTrainedError, consensus_prediction, predict_email

SAMPLE_PHISHING = (
    "Subject: Urgent Security Alert\n\n"
    "Dear Customer,\n\n"
    "We detected unusual activity on your account. Your account will be suspended "
    "within 24 hours unless you verify your identity immediately. Click the link "
    "below to confirm your password and prevent permanent deletion.\n\n"
    "Verify Now: http://secure-bank-verify-login.com/confirm\n\n"
    "Failure to act will result in account closure.\n"
)

SAMPLE_LEGITIMATE = (
    "Subject: Project Meeting Tomorrow\n\n"
    "Hi Ahmed,\n\n"
    "Just a reminder that our project meeting is scheduled for tomorrow at 10:00 AM "
    "in meeting room 305. We'll be discussing the Q4 report and reviewing the "
    "department budget.\n\n"
    "Please bring the printed copies of the attached documents.\n\n"
    "Best regards,\nMohammed\n"
)


def _set_text(value: str):
    st.session_state["email_input"] = value


def _badge(label):
    if label == "phishing":
        return '<span class="badge badge-danger">Phishing</span>'
    return '<span class="badge badge-success">Legitimate</span>'


def _try_log_to_db(result, email_text, threshold):
    try:
        from database.db import log_analysis
        log_analysis(result, email_text, threshold)
    except Exception:
        pass


def render():
    st.markdown(
        """
        <div class="hero">
            <h1>Email Analyzer</h1>
            <p>Analyze email text with trained classifiers</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.session_state.setdefault("email_input", "")

    c1, c2, c3 = st.columns(3)
    c1.button("Load Phishing Sample", on_click=_set_text, args=(SAMPLE_PHISHING,), use_container_width=True)
    c2.button("Load Legitimate Sample", on_click=_set_text, args=(SAMPLE_LEGITIMATE,), use_container_width=True)
    c3.button("Clear", on_click=_set_text, args=("",), use_container_width=True)

    email_text = st.text_area(
        "Email subject and body",
        height=280,
        max_chars=100_000,
        key="email_input",
    )

    col1, col2, col3 = st.columns(3)
    with col1:
        model_choice = st.selectbox(
            "Classification model",
            options=MODEL_NAMES,
            format_func=lambda x: MODEL_DISPLAY_NAMES.get(x, x),
        )
    with col2:
        threshold = st.slider("Decision threshold", 0.05, 0.95, 0.5, 0.05)
    with col3:
        use_consensus = st.checkbox("Use multi-model consensus", value=False)

    if not st.button("Analyze", type="primary"):
        return

    if not email_text.strip():
        st.error("Please enter an email message.")
        return

    with st.spinner("Analyzing..."):
        try:
            if use_consensus:
                _show_consensus(email_text, threshold)
            else:
                _show_single(email_text, model_choice, threshold)
            st.info(
                "This prediction is not proof that the message is safe or malicious. "
                "Verify the sender through an independent channel."
            )
        except ModelNotTrainedError as exc:
            st.error(str(exc))
        except (ValueError, OSError) as exc:
            st.error(f"Analysis failed: {exc}")


def _show_consensus(email_text, threshold):
    result = consensus_prediction(email_text, threshold)
    if "error" in result:
        st.error(result["error"])
        return

    label = result["consensus"]
    css = "result-phishing" if label == "phishing" else "result-legitimate"
    title = "⚠️ Potential Phishing Detected" if label == "phishing" else "✅ Classified as Legitimate"
    votes = result["votes"]

    st.markdown(
        f"""
        <div class="{css}">
            <span class="badge {'badge-danger' if label == 'phishing' else 'badge-success'}">
                Consensus: {label.title()}
            </span>
            <h3 style="margin:1rem 0 0.5rem 0;">{title}</h3>
            <p style="margin:0;">
                {votes['phishing']} of {result['total_models']} models classified this as phishing.
                Consensus confidence: {result['confidence']:.1%}
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("### Per-Model Breakdown")
    for name, res in result["per_model"].items():
        display = MODEL_DISPLAY_NAMES.get(name, name)
        col1, col2, col3 = st.columns(3)
        with col1:
            st.write(f"**{display}**")
        with col2:
            if "error" in res:
                st.warning(res["error"])
            else:
                st.markdown(_badge(res["label"]), unsafe_allow_html=True)
        with col3:
            if "error" not in res and res.get("probability") is not None:
                st.write(f"Confidence: {res['probability']:.1%}")


def _show_single(email_text, model_choice, threshold):
    result = predict_email(email_text, model_choice, threshold)

    if result["label"] == "phishing":
        st.markdown(
            """
            <div class="result-phishing">
                <span class="badge badge-danger">Phishing</span>
                <h3 style="margin:1rem 0 0.5rem 0;">⚠️ Potential Phishing Detected</h3>
                <p style="margin:0;">This email matches patterns of phishing or fraud.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            """
            <div class="result-legitimate">
                <span class="badge badge-success">Legitimate</span>
                <h3 style="margin:1rem 0 0.5rem 0;">✅ Classified as Legitimate</h3>
                <p style="margin:0;">This email appears legitimate based on the trained model.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Model", result["model_display"])
    c2.metric("Probability", f"{result['probability']:.1%}" if result["probability"] is not None else "N/A")
    c3.metric("Analysis Time", f"{result['elapsed_ms']} ms")
    c4.metric("Threshold", f"{threshold:.2f}")

    if result.get("note"):
        st.caption(result["note"])

    _try_log_to_db(result, email_text, threshold)

    st.markdown("### Signal Features")
    feats = result["features"]
    cols = st.columns(5)
    for i, (key, value) in enumerate(feats.items()):
        with cols[i % 5]:
            if isinstance(value, float):
                st.metric(key.replace("_", " ").title(), f"{value:.3f}")
            else:
                st.metric(key.replace("_", " ").title(), value)
