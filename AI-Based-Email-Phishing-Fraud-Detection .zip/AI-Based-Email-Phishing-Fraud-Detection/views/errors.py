import pandas as pd
import streamlit as st

from src.config import ERROR_ANALYSIS_DIR, MODEL_DISPLAY_NAMES, MODEL_NAMES
from src.error_analysis import load_error_summary


def render():
    st.markdown(
        """
        <div class="hero">
            <h1>Error Analysis</h1>
            <p>Misclassified emails and their patterns</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        "This page shows the emails that each model misclassified. "
        "Understanding these errors is part of Stage 7 (Testing, Comparison, "
        "and Documentation) from the proposal."
    )

    summaries = {}
    for name in MODEL_NAMES:
        summary = load_error_summary(name)
        if summary:
            summaries[name] = summary

    if not summaries:
        st.info(
            "No error analysis found. Run `python -m src.training` to generate it."
        )
        return

    st.markdown('<div class="section-title">Error Summary</div>', unsafe_allow_html=True)
    rows = []
    for name, summary in summaries.items():
        rows.append({
            "Model": MODEL_DISPLAY_NAMES.get(name, name),
            "Test Size": summary.get("total_test", 0),
            "Errors": summary.get("errors", 0),
            "False Positives": summary.get("false_positives", 0),
            "False Negatives": summary.get("false_negatives", 0),
        })

    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    st.markdown('<div class="section-title">Misclassified Examples</div>', unsafe_allow_html=True)

    for name, summary in summaries.items():
        display = MODEL_DISPLAY_NAMES.get(name, name)
        examples = summary.get("examples", [])
        if not examples:
            continue

        with st.expander(f"📋 {display} — {len(examples)} examples"):
            for ex in examples:
                kind = ex.get("type", "")
                color = "badge-danger" if kind == "false_positive" else "badge-success"
                label = "False Positive" if kind == "false_positive" else "False Negative"

                st.markdown(
                    f'<span class="badge {color}">{label}</span>',
                    unsafe_allow_html=True,
                )
                st.markdown(f"**True:** `{ex.get('true_label')}`  ·  "
                            f"**Predicted:** `{ex.get('predicted')}`")
                st.text(ex.get("text", "")[:500])
                st.markdown("---")

    st.markdown('<div class="section-title">Exported Files</div>', unsafe_allow_html=True)
    if ERROR_ANALYSIS_DIR.exists():
        files = sorted(ERROR_ANALYSIS_DIR.glob("*"))
        if files:
            for path in files:
                st.markdown(f"- `{path.name}`")
        else:
            st.info("No exported files yet.")
    else:
        st.info("Error analysis directory does not exist.")
