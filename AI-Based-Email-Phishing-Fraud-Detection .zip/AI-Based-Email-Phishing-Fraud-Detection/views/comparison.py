import plotly.graph_objects as go
import streamlit as st

from src.config import (
    CHARTS_DIR,
    MATRICES_DIR,
    MODEL_DESCRIPTIONS,
    MODEL_DISPLAY_NAMES,
    REPORTS_DIR,
)
from src.visualization import load_metadata, load_metrics


def _display_name_from_stem(stem: str) -> str:
    clean = stem.replace("confusion_matrix_", "").replace("roc_", "").replace("pr_", "")
    return MODEL_DISPLAY_NAMES.get(clean, clean.replace("_", " ").title())


def render():
    st.markdown(
        """
        <div class="hero">
            <h1>Model Comparison</h1>
            <p>Performance comparison and evaluation artifacts</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    metrics = load_metrics()
    if metrics.empty:
        st.warning("No metrics found. Train the models first.")
        return

    st.markdown('<div class="section-title">Performance Overview</div>', unsafe_allow_html=True)
    display_cols = ["model", "accuracy", "precision", "recall", "f1_score", "roc_auc"]
    display_cols = [c for c in display_cols if c in metrics.columns]

    st.dataframe(
        metrics[display_cols].style.format({
            c: "{:.4f}" for c in display_cols if c != "model"
        }),
        use_container_width=True, hide_index=True,
    )

    best = metrics.sort_values("f1_score", ascending=False).iloc[0]
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">Best Model by F1-Score</div>
            <div class="metric-value">{best['model']}</div>
            <p style="color:#64748b;margin:0.5rem 0 0 0;">
                F1: {best['f1_score']:.4f} · Acc: {best['accuracy']:.4f}
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown('<div class="section-title">Radar Comparison</div>', unsafe_allow_html=True)
    categories = ["accuracy", "precision", "recall", "f1_score"]
    categories = [c for c in categories if c in metrics.columns]

    fig = go.Figure()
    colors = {"random_forest": "#2563eb", "svm": "#16a34a", "naive_bayes": "#f59e0b"}

    for _, row in metrics.iterrows():
        values = [row[c] for c in categories]
        values.append(values[0])
        labels = [c.replace("_", " ").title() for c in categories]
        labels.append(labels[0])
        fig.add_trace(go.Scatterpolar(
            r=values, theta=labels, fill="toself",
            name=row["model"], line_color=colors.get(row["model"], "#64748b"),
        ))

    fig.update_layout(
        polar=dict(radialaxis=dict(
            visible=True,
            range=[
                max(0.0, metrics[categories].min().min() - 0.05),
                min(1.0, metrics[categories].max().max() + 0.02),
            ],
        )),
        showlegend=True, height=500,
        margin=dict(l=40, r=40, t=40, b=40),
        paper_bgcolor="rgba(0,0,0,0)",
    )
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="section-title">ROC Curves</div>', unsafe_allow_html=True)
    roc_files = sorted(CHARTS_DIR.glob("roc_*.png")) if CHARTS_DIR.exists() else []
    if roc_files:
        cols = st.columns(min(3, len(roc_files)))
        for i, path in enumerate(roc_files):
            with cols[i % len(cols)]:
                st.image(str(path), caption=_display_name_from_stem(path.stem), use_container_width=True)
    else:
        st.info("ROC curves will appear after training.")

    st.markdown('<div class="section-title">Precision-Recall Curves</div>', unsafe_allow_html=True)
    pr_files = sorted(CHARTS_DIR.glob("pr_*.png")) if CHARTS_DIR.exists() else []
    if pr_files:
        cols = st.columns(min(3, len(pr_files)))
        for i, path in enumerate(pr_files):
            with cols[i % len(cols)]:
                st.image(str(path), caption=_display_name_from_stem(path.stem), use_container_width=True)
    else:
        st.info("PR curves will appear after training.")

    st.markdown('<div class="section-title">Confusion Matrices</div>', unsafe_allow_html=True)
    matrix_files = sorted(MATRICES_DIR.glob("*.png")) if MATRICES_DIR.exists() else []
    if matrix_files:
        cols = st.columns(min(3, len(matrix_files)))
        for i, path in enumerate(matrix_files):
            with cols[i % len(cols)]:
                st.image(str(path), caption=_display_name_from_stem(path.stem), use_container_width=True)
    else:
        st.info("Confusion matrices will appear after training.")

    st.markdown('<div class="section-title">Model Descriptions</div>', unsafe_allow_html=True)
    for name in metrics["model"]:
        display = MODEL_DISPLAY_NAMES.get(name, name)
        desc = MODEL_DESCRIPTIONS.get(name, "")
        st.markdown(
            f'<div class="info-box" style="margin-bottom:1rem;">'
            f"<strong>{display}</strong><br>{desc}</div>",
            unsafe_allow_html=True,
        )

    st.markdown('<div class="section-title">Classification Reports</div>', unsafe_allow_html=True)
    report_files = sorted(REPORTS_DIR.glob("*.json")) if REPORTS_DIR.exists() else []
    if report_files:
        for path in report_files:
            with st.expander(f"📄 {path.stem.replace('_', ' ').title()}"):
                st.json(path.read_text(encoding="utf-8"))
    else:
        st.info("Reports will appear after training.")

    st.markdown('<div class="section-title">Training Metadata</div>', unsafe_allow_html=True)
    metadata = load_metadata()
    if metadata:
        with st.expander("📋 View metadata.json"):
            st.json(metadata)
    else:
        st.info("Metadata will appear after training.")
