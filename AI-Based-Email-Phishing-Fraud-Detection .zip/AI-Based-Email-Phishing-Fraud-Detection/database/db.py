import hashlib
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from src.config import DATABASE_DIR, DATABASE_FILE


SCHEMA_FILE = DATABASE_DIR / "schema.sql"


def _ensure_directory():
    DATABASE_DIR.mkdir(parents=True, exist_ok=True)


def _load_schema() -> str:
    if SCHEMA_FILE.exists():
        return SCHEMA_FILE.read_text(encoding="utf-8")
    return ""


@contextmanager
def get_connection():
    _ensure_directory()
    conn = sqlite3.connect(DATABASE_FILE)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_database() -> None:
    schema = _load_schema()
    if not schema:
        return
    with get_connection() as conn:
        conn.executescript(schema)


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:32]


def log_analysis(result: dict, email_text: str, threshold: float) -> int:
    init_database()
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO analyses (
                created_at, model_name, threshold, email_length,
                prediction, probability, score, elapsed_ms, input_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.now(timezone.utc).isoformat(),
                result.get("model", "unknown"),
                float(threshold),
                len(email_text),
                result.get("label", "unknown"),
                result.get("probability"),
                result.get("score"),
                result.get("elapsed_ms"),
                _hash_text(email_text),
            ),
        )
        return cursor.lastrowid


def log_batch_run(
    model_name: str,
    threshold: float,
    total: int,
    phishing: int,
    legitimate: int,
    errors: int,
) -> int:
    init_database()
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO batch_runs (
                created_at, model_name, threshold,
                total_rows, phishing_count, legitimate_count, error_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.now(timezone.utc).isoformat(),
                model_name,
                float(threshold),
                int(total),
                int(phishing),
                int(legitimate),
                int(errors),
            ),
        )
        return cursor.lastrowid


def fetch_recent_analyses(limit: int = 50) -> list:
    init_database()
    with get_connection() as conn:
        cursor = conn.execute(
            "SELECT * FROM analyses ORDER BY id DESC LIMIT ?", (limit,)
        )
        return [dict(row) for row in cursor.fetchall()]


def fetch_analysis_stats() -> dict:
    init_database()
    with get_connection() as conn:
        total = conn.execute("SELECT COUNT(*) FROM analyses").fetchone()[0]
        phishing = conn.execute(
            "SELECT COUNT(*) FROM analyses WHERE prediction = 'phishing'"
        ).fetchone()[0]
        legitimate = conn.execute(
            "SELECT COUNT(*) FROM analyses WHERE prediction = 'legitimate'"
        ).fetchone()[0]
    return {
        "total": int(total),
        "phishing": int(phishing),
        "legitimate": int(legitimate),
    }


def clear_analyses() -> None:
    init_database()
    with get_connection() as conn:
        conn.execute("DELETE FROM analyses")
