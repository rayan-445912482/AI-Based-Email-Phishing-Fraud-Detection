-- Database schema for AI-Based Email Phishing & Fraud Detection
-- Author: ALI ASAAD A ALSUWAYRI (Member 2)
-- Purpose: Store analysis history and model metadata.

CREATE TABLE IF NOT EXISTS analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    model_name TEXT NOT NULL,
    threshold REAL NOT NULL,
    email_length INTEGER NOT NULL,
    prediction TEXT NOT NULL,
    probability REAL,
    score REAL,
    elapsed_ms REAL,
    input_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_analyses_created_at ON analyses(created_at);
CREATE INDEX IF NOT EXISTS idx_analyses_prediction ON analyses(prediction);

CREATE TABLE IF NOT EXISTS batch_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    model_name TEXT NOT NULL,
    threshold REAL NOT NULL,
    total_rows INTEGER NOT NULL,
    phishing_count INTEGER NOT NULL,
    legitimate_count INTEGER NOT NULL,
    error_count INTEGER NOT NULL
);
